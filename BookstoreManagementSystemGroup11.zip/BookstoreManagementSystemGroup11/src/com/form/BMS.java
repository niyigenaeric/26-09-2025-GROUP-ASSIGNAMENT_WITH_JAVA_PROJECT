package com.form;

import java.awt.BorderLayout;
import javax.swing.*;

import com.panel.BookPanel;
import com.panel.CategoryPanel;
import com.panel.OrderPanel;
import com.panel.ReviewPanel;
import com.panel.UserPanel;

public class BMS extends JFrame {

    public BMS(String role, int userid) {
        JTabbedPane tabs = new JTabbedPane();
        setTitle("Bookstore Management System");
        setSize(900, 600);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null); // center the window

        try {
            // Admin access: can manage everything
            if (role.equalsIgnoreCase("admin")) {
                tabs.add("Users", new UserPanel(role, userid));
                tabs.add("Books", new BookPanel());
                tabs.add("Categories", new CategoryPanel());
                tabs.add("Orders", new OrderPanel());
                tabs.add("Reviews", new ReviewPanel());
            } 
            // Manager/Staff access: limited access
            else if (role.equalsIgnoreCase("staff")) {
                tabs.add("Books", new BookPanel());
                tabs.add("Orders", new OrderPanel());
            } 
            // Customer access: view only
            else if (role.equalsIgnoreCase("customer")) {
                tabs.add("My Orders", new OrderPanel());
                tabs.add("Books & Reviews", new BookPanel()); // include review functionality
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error initializing panel: " + ex.getMessage());
        }

        add(tabs, BorderLayout.CENTER);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Optional main for testing
    public static void main(String[] args) {
        new BMS("admin", 1); // test with admin role
    }
}
