package com.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.util.DB;

public class ReviewPanel extends JPanel implements ActionListener {

    JTextField idtxt = new JTextField();
    JTextField bookidtxt = new JTextField();
    JTextField useridtxt = new JTextField();
    JTextField ratingtxt = new JTextField();
    JTextField commenttxt = new JTextField();

    JButton addBtn = new JButton("Add"), 
            updateBtn = new JButton("Update"), 
            deleteBtn = new JButton("Delete"),
            loadBtn = new JButton("Load");

    JTable table;
    DefaultTableModel model;

    public ReviewPanel() {
        setLayout(null);

        String[] columnNames = { "ReviewID", "BookID", "UserID", "Rating", "Comment" };
        model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 200, 800, 300);
        add(sp);

        int y = 20;
        addField("ReviewID", idtxt, y); y += 30;
        addField("BookID", bookidtxt, y); y += 30;
        addField("UserID", useridtxt, y); y += 30;
        addField("Rating", ratingtxt, y); y += 30;
        addField("Comment", commenttxt, y); y += 30;

        addButton();

        // register listeners
        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);
        loadBtn.addActionListener(this);

        // Table row selection fills the fields
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                    int row = table.getSelectedRow();
                    idtxt.setText(model.getValueAt(row, 0).toString());
                    bookidtxt.setText(model.getValueAt(row, 1).toString());
                    useridtxt.setText(model.getValueAt(row, 2).toString());
                    ratingtxt.setText(model.getValueAt(row, 3).toString());
                    commenttxt.setText(model.getValueAt(row, 4).toString());
                }
            }
        });

        loadReviews(); // Load reviews at startup
    }

    private void addButton() {
        addBtn.setBounds(300, 20, 100, 30);
        updateBtn.setBounds(300, 60, 100, 30);
        deleteBtn.setBounds(300, 100, 100, 30);
        loadBtn.setBounds(300, 140, 100, 30);

        add(addBtn);
        add(updateBtn);
        add(deleteBtn);
        add(loadBtn);
    }

    private void addField(String lbl, JComponent comp, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 80, 25);
        comp.setBounds(100, y, 150, 25);
        add(l);
        add(comp);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try (Connection con = DB.getConnection()) {
            if (e.getSource() == addBtn) {
                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO BookReviews(BookID, UserID, Rating, Comment) VALUES(?,?,?,?)");
                ps.setInt(1, Integer.parseInt(bookidtxt.getText()));
                ps.setInt(2, Integer.parseInt(useridtxt.getText()));
                ps.setInt(3, Integer.parseInt(ratingtxt.getText()));
                ps.setString(4, commenttxt.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Review Added!");
                loadReviews();

            } else if (e.getSource() == updateBtn) {
                if (idtxt.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Select a review to update!");
                    return;
                }
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE BookReviews SET BookID=?, UserID=?, Rating=?, Comment=? WHERE ReviewID=?");
                ps.setInt(1, Integer.parseInt(bookidtxt.getText()));
                ps.setInt(2, Integer.parseInt(useridtxt.getText()));
                ps.setInt(3, Integer.parseInt(ratingtxt.getText()));
                ps.setString(4, commenttxt.getText());
                ps.setInt(5, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Review Updated!");
                loadReviews();

            } else if (e.getSource() == deleteBtn) {
                if (idtxt.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Select a review to delete!");
                    return;
                }
                PreparedStatement ps = con.prepareStatement("DELETE FROM BookReviews WHERE ReviewID=?");
                ps.setInt(1, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Review Deleted!");
                loadReviews();

            } else if (e.getSource() == loadBtn) {
                loadReviews();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadReviews() {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM BookReviews");
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("ReviewID"),
                        rs.getInt("BookID"),
                        rs.getInt("UserID"),
                        rs.getInt("Rating"),
                        rs.getString("Comment")
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
