package com.panel;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import com.util.DB;

public class OrderPanel extends JPanel implements ActionListener {

    JTextField txtOrderId = new JTextField();  // locked
    JTextField txtBookId = new JTextField();
    JTextField txtUserId = new JTextField();
    JTextField txtQuantity = new JTextField();

    JButton addBtn = new JButton("Add"),
            updateBtn = new JButton("Update"),
            deleteBtn = new JButton("Delete"),
            loadBtn = new JButton("Load");

    JTable table;
    DefaultTableModel model;

    public OrderPanel() {
        setLayout(null);

        // Lock OrderID
        txtOrderId.setEditable(false);

        String[] labels = {"OrderID", "BookID", "UserID", "Quantity", "OrderDate"};
        model = new DefaultTableModel(labels, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 200, 800, 300);
        add(sp);

        int y = 20;
        addField("OrderID", txtOrderId, y); y += 30;
        addField("BookID", txtBookId, y); y += 30;
        addField("UserID", txtUserId, y); y += 30;
        addField("Quantity", txtQuantity, y); y += 30;

        addButton();

        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);
        loadBtn.addActionListener(this);

        // Table row selection
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                txtOrderId.setText(model.getValueAt(row, 0).toString());
                txtBookId.setText(model.getValueAt(row, 1).toString());
                txtUserId.setText(model.getValueAt(row, 2).toString());
                txtQuantity.setText(model.getValueAt(row, 3).toString());
            }
        });

        loadOrders();
    }

    private void addButton() {
        addBtn.setBounds(300, 20, 100, 30);
        updateBtn.setBounds(300, 60, 100, 30);
        deleteBtn.setBounds(300, 100, 100, 30);
        loadBtn.setBounds(300, 140, 100, 30);

        add(addBtn);
        add(updateBtn);
        add(deleteBtn);
        add(loadBtn);
    }

    private void addField(String lbl, JComponent txt, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 80, 25);
        txt.setBounds(100, y, 150, 25);
        add(l);
        add(txt);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try (Connection con = DB.getConnection()) {
            if (e.getSource() == addBtn) {
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO orders (BookID, UserID, Quantity) VALUES (?,?,?)"
                );
                ps.setInt(1, Integer.parseInt(txtBookId.getText()));
                ps.setInt(2, Integer.parseInt(txtUserId.getText()));
                ps.setInt(3, Integer.parseInt(txtQuantity.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Order Added!");
                loadOrders();
            } else if (e.getSource() == updateBtn) {
                if (txtOrderId.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement(
                    "UPDATE orders SET BookID=?, UserID=?, Quantity=? WHERE OrderID=?"
                );
                ps.setInt(1, Integer.parseInt(txtBookId.getText()));
                ps.setInt(2, Integer.parseInt(txtUserId.getText()));
                ps.setInt(3, Integer.parseInt(txtQuantity.getText()));
                ps.setInt(4, Integer.parseInt(txtOrderId.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Order Updated!");
                loadOrders();
            } else if (e.getSource() == deleteBtn) {
                if (txtOrderId.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM orders WHERE OrderID=?"
                );
                ps.setInt(1, Integer.parseInt(txtOrderId.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Order Deleted!");
                loadOrders();
            } else if (e.getSource() == loadBtn) {
                loadOrders();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        }
    }

    private void loadOrders() {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM orders");
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("OrderID"),
                    rs.getInt("BookID"),
                    rs.getInt("UserID"),
                    rs.getInt("Quantity"),
                    rs.getTimestamp("OrderDate")
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
