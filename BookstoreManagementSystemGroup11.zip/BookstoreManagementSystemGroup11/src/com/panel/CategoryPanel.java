package com.panel;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import com.util.DB;

public class CategoryPanel extends JPanel implements ActionListener {

    JTextField txtCategoryId = new JTextField();   // Locked
    JTextField txtName = new JTextField();
    JTextArea txtDescription = new JTextArea();

    JButton addBtn = new JButton("Add"),
            updateBtn = new JButton("Update"),
            deleteBtn = new JButton("Delete"),
            loadBtn = new JButton("Load");

    JTable table;
    DefaultTableModel model;

    public CategoryPanel() {
        setLayout(null);

        // Lock the ID field
        txtCategoryId.setEditable(false);

        String[] labels = {"CategoryID", "Name", "Description", "CreatedAt"};
        model = new DefaultTableModel(labels, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 200, 800, 300);
        add(sp);

        int y = 20;
        addField("CategoryID", txtCategoryId, y); y += 30;
        addField("Name", txtName, y); y += 30;

        JLabel ldesc = new JLabel("Description");
        ldesc.setBounds(20, y, 80, 25);
        add(ldesc);
        JScrollPane descSp = new JScrollPane(txtDescription);
        descSp.setBounds(100, y, 150, 60);
        add(descSp);
        y += 70;

        addButton();

        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);
        loadBtn.addActionListener(this);

        // Table row click -> load data into fields
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                txtCategoryId.setText(model.getValueAt(row, 0).toString());
                txtName.setText(model.getValueAt(row, 1).toString());
                txtDescription.setText(model.getValueAt(row, 2).toString());
            }
        });

        loadCategories();
    }

    private void addButton() {
        addBtn.setBounds(300, 20, 100, 30);
        updateBtn.setBounds(300, 60, 100, 30);
        deleteBtn.setBounds(300, 100, 100, 30);
        loadBtn.setBounds(300, 140, 100, 30);

        add(addBtn);
        add(updateBtn);
        add(deleteBtn);
        add(loadBtn);
    }

    private void addField(String lbl, JComponent txt, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 80, 25);
        txt.setBounds(100, y, 150, 25);
        add(l);
        add(txt);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try (Connection con = DB.getConnection()) {
            if (e.getSource() == addBtn) {
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO bookcategories(Name, Description) VALUES (?,?)"
                );
                ps.setString(1, txtName.getText());
                ps.setString(2, txtDescription.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Category Added!");
                loadCategories();
            } else if (e.getSource() == updateBtn) {
                if (txtCategoryId.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement(
                    "UPDATE bookcategories SET Name=?, Description=? WHERE CategoryID=?"
                );
                ps.setString(1, txtName.getText());
                ps.setString(2, txtDescription.getText());
                ps.setInt(3, Integer.parseInt(txtCategoryId.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Category Updated!");
                loadCategories();
            } else if (e.getSource() == deleteBtn) {
                if (txtCategoryId.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM bookcategories WHERE CategoryID=?"
                );
                ps.setInt(1, Integer.parseInt(txtCategoryId.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Category Deleted!");
                loadCategories();
            } else if (e.getSource() == loadBtn) {
                loadCategories();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        }
    }

    private void loadCategories() {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM bookcategories");
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("CategoryID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getTimestamp("CreatedAt")
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
