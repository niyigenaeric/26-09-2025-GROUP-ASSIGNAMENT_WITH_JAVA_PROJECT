package com.panel;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import com.util.DB;

public class BookPanel extends JPanel implements ActionListener {

    JTextField idtxt = new JTextField();
    
    JTextField titletxt = new JTextField();
    JTextArea descriptiontxt = new JTextArea();
    JTextField authortxt = new JTextField();
    JTextField genretxt = new JTextField();
    JTextField pricetxt = new JTextField();
    JTextField stocktxt = new JTextField();

    JButton addBtn = new JButton("Add"), 
            updateBtn = new JButton("Update"), 
            deleteBtn = new JButton("Delete"),
            loadBtn = new JButton("Load");

    JTable table;
    DefaultTableModel model;

    public BookPanel() {
        setLayout(null);
        String[] labels = { "BookID", "Title", "Description", "Author", "Genre", "Price", "Stock", "CreatedAt" };
        model = new DefaultTableModel(labels, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 280, 900, 300);
        add(sp);

        int y = 20;
        addField("BookID", idtxt, y); y+=30;
        idtxt.setEditable(false);
        addField("Title", titletxt, y); y+=30;
        addTextArea("Description", descriptiontxt, y); y+=60;
        addField("Author", authortxt, y); y+=30;
        addField("Genre", genretxt, y); y+=30;
        addField("Price", pricetxt, y); y+=30;
        addField("Stock", stocktxt, y); y+=30;

        addButton();

        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);
        loadBtn.addActionListener(this);

        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                idtxt.setText(model.getValueAt(row, 0).toString());
                titletxt.setText(model.getValueAt(row, 1).toString());
                descriptiontxt.setText(model.getValueAt(row, 2) == null ? "" : model.getValueAt(row, 2).toString());
                authortxt.setText(model.getValueAt(row, 3) == null ? "" : model.getValueAt(row, 3).toString());
                genretxt.setText(model.getValueAt(row, 4) == null ? "" : model.getValueAt(row, 4).toString());
                pricetxt.setText(model.getValueAt(row, 5).toString());
                stocktxt.setText(model.getValueAt(row, 6).toString());
            }
        });

        loadBooks();
    }

    private void addButton() {
        addBtn.setBounds(320, 20, 100, 30);
        updateBtn.setBounds(320, 60, 100, 30);
        deleteBtn.setBounds(320, 100, 100, 30);
        loadBtn.setBounds(320, 140, 100, 30);

        add(addBtn);
        add(updateBtn);
        add(deleteBtn);
        add(loadBtn);
    }

    private void addField(String lbl, JComponent txt, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 80, 25);
        txt.setBounds(100, y, 200, 25);
        add(l);
        add(txt);
    }

    private void addTextArea(String lbl, JTextArea txt, int y) {
        JLabel l = new JLabel(lbl);
        l.setBounds(20, y, 80, 25);
        JScrollPane scroll = new JScrollPane(txt);
        scroll.setBounds(100, y, 200, 50);
        add(l);
        add(scroll);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try (Connection con = DB.getConnection()) {
            if (e.getSource() == addBtn) {
                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO books(title, description, author, genre, price, stock, createdat) VALUES(?,?,?,?,?,?,NOW())");
                ps.setString(1, titletxt.getText());
                ps.setString(2, descriptiontxt.getText());
                ps.setString(3, authortxt.getText());
                ps.setString(4, genretxt.getText());
                ps.setBigDecimal(5, new java.math.BigDecimal(pricetxt.getText()));
                ps.setInt(6, Integer.parseInt(stocktxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book Added!");
                loadBooks();
            } else if (e.getSource() == updateBtn) {
                if (idtxt.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE books SET title=?, description=?, author=?, genre=?, price=?, stock=? WHERE bookid=?");
                ps.setString(1, titletxt.getText());
                ps.setString(2, descriptiontxt.getText());
                ps.setString(3, authortxt.getText());
                ps.setString(4, genretxt.getText());
                ps.setBigDecimal(5, new java.math.BigDecimal(pricetxt.getText()));
                ps.setInt(6, Integer.parseInt(stocktxt.getText()));
                ps.setInt(7, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book Updated!");
                loadBooks();
            } else if (e.getSource() == deleteBtn) {
                if (idtxt.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement("DELETE FROM books WHERE bookid=?");
                ps.setInt(1, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book Deleted!");
                loadBooks();
            } else if (e.getSource() == loadBtn) {
                loadBooks();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        }
    }

    private void loadBooks() {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM books");
            while (rs.next()) {
                model.addRow(new Object[] {
                    rs.getInt("bookid"),
                    rs.getString("title"),
                    rs.getString("description"),
                    rs.getString("author"),
                    rs.getString("genre"),
                    rs.getBigDecimal("price"),
                    rs.getInt("stock"),
                    rs.getTimestamp("createdat")
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        }
    }
}
